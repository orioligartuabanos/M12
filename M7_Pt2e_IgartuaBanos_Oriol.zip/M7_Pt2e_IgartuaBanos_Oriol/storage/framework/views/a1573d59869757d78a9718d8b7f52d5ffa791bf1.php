<!-- Navigation -->
<nav>
    <a href="<?php echo e(route('home')); ?>">Inici</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('llibre_list')); ?>">Llibres</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('autor_list')); ?>">Autors</a>
</nav><?php /**PATH /var/www/html/M7_1/M7_Pt2b_IgartuaBanos_Oriol/resources/views/navbar.blade.php ENDPATH**/ ?>