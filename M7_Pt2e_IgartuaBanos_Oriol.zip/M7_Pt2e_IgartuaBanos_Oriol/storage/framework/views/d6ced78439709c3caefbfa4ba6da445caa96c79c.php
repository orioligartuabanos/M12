<?php echo e($slot); ?>

<?php /**PATH /var/www/html/M7_1/M7_Pt2e_IgartuaBanos_Oriol/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>